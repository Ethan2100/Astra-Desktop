from PySide6.QtWidgets import QApplication
from ui.main_window import MainWindow
from core.logging_config import configure_logging
from core.database import Database
from core.config import APP_NAME

def main():
    configure_logging()
    database = Database()
    database.initialize()

    app = QApplication([])
    app.setApplicationName(APP_NAME)
    app.setQuitOnLastWindowClosed(True)

    window = MainWindow(database)
    window.show()
    app.exec()

if __name__ == "__main__":
    main()
