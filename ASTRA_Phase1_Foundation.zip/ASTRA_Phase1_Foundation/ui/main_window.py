import logging
from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QLabel,
    QPushButton, QFrame, QListWidget, QStackedWidget
)

log = logging.getLogger(__name__)

class MainWindow(QMainWindow):
    def __init__(self, database):
        super().__init__()
        self.database = database
        self.setWindowTitle("ASTRA Desktop")
        self.resize(1000, 680)
        self.setMinimumSize(760, 520)
        self.setStyleSheet("""
            QMainWindow, QWidget { background: #0b1020; color: #e8f0ff; }
            QFrame#Sidebar { background: #10182b; border: 1px solid #1e2b45; border-radius: 14px; }
            QLabel#Brand { color: #7dd3fc; font-size: 23px; font-weight: 700; }
            QLabel#Muted { color: #91a4c2; }
            QPushButton {
                background: #17243b; color: #e8f0ff; border: 1px solid #263a5b;
                border-radius: 9px; padding: 10px 14px; text-align: left;
            }
            QPushButton:hover { background: #203453; }
            QLabel#Welcome { font-size: 30px; font-weight: 650; }
            QListWidget { background: #10182b; border: 1px solid #263a5b; border-radius: 10px; padding: 8px; }
        """)

        root = QWidget()
        self.setCentralWidget(root)
        layout = QHBoxLayout(root)
        layout.setContentsMargins(18, 18, 18, 18)
        layout.setSpacing(16)

        sidebar = QFrame()
        sidebar.setObjectName("Sidebar")
        sidebar.setFixedWidth(220)
        side = QVBoxLayout(sidebar)
        side.setContentsMargins(16, 18, 16, 18)
        side.setSpacing(12)

        brand = QLabel("✦ ASTRA")
        brand.setObjectName("Brand")
        side.addWidget(brand)
        subtitle = QLabel("DESKTOP ASSISTANT")
        subtitle.setObjectName("Muted")
        side.addWidget(subtitle)
        side.addSpacing(18)

        self.chat_button = QPushButton("  ◉   Chat")
        self.memory_button = QPushButton("  ◈   Memory")
        self.settings_button = QPushButton("  ⚙   Settings")
        side.addWidget(self.chat_button)
        side.addWidget(self.memory_button)
        side.addWidget(self.settings_button)
        side.addStretch(1)

        status = QLabel("●  Foundation ready")
        status.setObjectName("Muted")
        side.addWidget(status)

        self.pages = QStackedWidget()
        self.pages.addWidget(self._page(
            "Welcome to ASTRA",
            "Your new local-first desktop assistant starts here.",
            "Phase 1 is the foundation. Next we'll add the floating orb and connect Ollama."
        ))
        self.pages.addWidget(self._page(
            "Memory foundation",
            "Persistent storage is ready.",
            f"Database location: {self.database.path}"
        ))
        self.pages.addWidget(self._page(
            "Settings",
            "Configuration will live here.",
            "No cloud API is configured or called in this foundation build."
        ))

        self.chat_button.clicked.connect(lambda: self.pages.setCurrentIndex(0))
        self.memory_button.clicked.connect(lambda: self.pages.setCurrentIndex(1))
        self.settings_button.clicked.connect(lambda: self.pages.setCurrentIndex(2))

        layout.addWidget(sidebar)
        layout.addWidget(self.pages, 1)
        log.info("ASTRA main window created")

    def _page(self, title, subtitle, detail):
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(30, 28, 30, 28)
        layout.setSpacing(14)
        heading = QLabel(title)
        heading.setObjectName("Welcome")
        heading.setWordWrap(True)
        description = QLabel(subtitle)
        description.setStyleSheet("font-size: 16px; color: #a9bddb;")
        detail_label = QLabel(detail)
        detail_label.setStyleSheet("color: #7f96b8; font-size: 13px;")
        detail_label.setWordWrap(True)
        layout.addWidget(heading)
        layout.addWidget(description)
        layout.addSpacing(10)
        layout.addWidget(detail_label)
        layout.addStretch(1)
        return page
